$(document).ready(function(){

    $('#cat1').click(function(){
        $('#cat1').fadeOut('slow');
    });

    $('#cat2').click(function(){
        $('#cat2').fadeOut('slow');
    });

    $('#cat3').click(function(){
        $('#cat3').fadeOut('slow');
    });

    $('#cat4').click(function(){
        $('#cat4').fadeOut('slow');
    });

    $('#cat5').click(function(){
        $('#cat5').fadeOut('slow');
    });

    $('#cat6').click(function(){
        $('#cat6').fadeOut('slow');
    });

    $('#cat7').click(function(){
        $('#cat7').fadeOut('slow');
    });

    $('#cat8').click(function(){
        $('#cat8').fadeOut('slow');
    });
    $('#restore').click(function(){
        $('img').fadeIn('slow');
    });
});